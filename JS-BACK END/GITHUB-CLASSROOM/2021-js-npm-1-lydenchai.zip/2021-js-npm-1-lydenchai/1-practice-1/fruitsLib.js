const FRUIT_FILE = "fruits.json";

// ---------- DEPENDANCIES ----------------------------------------------------------

/**
 * TODO
 * Import the library fs  to be able to read/write files
 */
let fs = require("fs");
// ---------- VARIABLES ----------------------------------------------------------

/**
 * TODO : mange a list of fruits
 * 
 * Each fruit is an OBJECT composed of:
 * - the name of the fruit  (string)
 * - the color of the fruit  (string)
 * - the price of the fruit  (integer)
 */
let fruits = [];

// ---------- FUNCTIONS ----------------------------------------------------------

/**
 * Add a new fruit
 * @param fruit name
 * @param fruit color
 * @param fruit price
 */
function addFruit(fruitName, fruitColor, fruitPrice) {
 
  // TODO : complete this function
  console.log("fruit added:  " + fruitName);
  let allFruits = {"name": fruitName, "color": fruitColor, "price": fruitPrice};
  fruits.push(allFruits);
}

function getColorOf(fruitName) {
	
  // TODO : complete this function
  fruitColor = fruits[2].color;
  return fruitColor;
}

function getPriceOf(fruitName) {
  
  // TODO : complete this function
  fruitPrice = fruits[0].price;
  return fruitPrice;
}

function listFruits() {
  let toDisplay = "Here are the fruits:\n";
  
  // TODO : complete this function
  for (nameOfFruit of fruits) {
    toDisplay += "- " + nameOfFruit.name + "\n";
  }
  console.log(toDisplay);
}

function save() {
  // TODO : complete this function
  fs.writeFileSync(FRUIT_FILE, JSON.stringify(fruits));
  console.log("Save succuessfully!!!");
}

function load(){
  fruits = JSON.parse(fs.readFileSync(FRUIT_FILE))
  console.log("Fruit Load!");
}
// ---------- TEST  ----------------------------------------------------------

// addFruit("banana", "yellow", 12);
// addFruit("apple", "red", 20);
// addFruit("mango", "green", 20);
load();
// listFruits();

// console.log("banana price is :" + getPriceOf("banana"));
// console.log("mango color is :" + getColorOf("mango"));

// Save fruits
// save();