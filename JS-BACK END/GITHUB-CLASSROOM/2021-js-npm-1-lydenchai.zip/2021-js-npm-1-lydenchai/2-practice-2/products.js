const fs = require('fs');
const PRODUCTS_FILE = "products.json";
let productList =[];

// ---------- DEPENDANCIES ----------------------------------------------------------

/**
 * TODO
 * Import the library fs  to be able to read/write files
 */

// ---------- VARIABLES ----------------------------------------------------------

/**
 * TODO : mange a list of products
 * 
 * Each product is an OBJECT composed of:
 * - the name of the product  (string)
 * - the category  of the product  (string)
 * - the price of the fruit  (integer)
 */

// ---------- FUNCTIONS ----------------------------------------------------------

/**
 * Add a new product
 * @param product name
 * @param product category
 * @param product price
 */
function addProduct(productName, category, price) {
 
   // TODO : complete this function
   let product={
      name :productName,
      category :category,
      price : price,
   }
   productList.push(product)
  console.log("product added:  " + productName);
}

function getMostExpensiveProduct() {
	
   // TODO : complete this function
   let expensivePrice = productList[0].price;
   let expensiveProduct = '';
   for(let product of productList){
      if(product.price >= expensivePrice){
         expensivePrice = product.price;
         expensiveProduct = product.name
      }
   }
   return expensiveProduct;
   // return null;
}

function save() {
   // TODO : complete this function
   fs.writeFileSync(PRODUCTS_FILE,JSON.stringify(productList))
}
function load(){
   productList = JSON.parse(fs.readFileSync(PRODUCTS_FILE))
}

// ---------- TEST  ----------------------------------------------------------

addProduct("piano", "music", 400);
addProduct("iphone", "phone", 500);
addProduct("french fries", "food", 20);

console.log("Most expensive product is  :" + getMostExpensiveProduct());

// Save fruits
save();
module.exports={
   addProduct,
   getMostExpensiveProduct
}