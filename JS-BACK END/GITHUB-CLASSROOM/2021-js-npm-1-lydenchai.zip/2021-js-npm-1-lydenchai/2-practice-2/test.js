const {addProduct,getMostExpensiveProduct} = require('./products')
addProduct("piano", "music", 400);
addProduct("iphone", "phone", 500);
addProduct("french fries", "food", 20);
getMostExpensiveProduct();
console.log("Most expensive product is  :" + getMostExpensiveProduct());
