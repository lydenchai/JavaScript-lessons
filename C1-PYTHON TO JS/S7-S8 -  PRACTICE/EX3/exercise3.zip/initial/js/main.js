let arrOne = [1, 3, 6, 7, 9];
let arrTwo = [4, 3, 5, 9, 1];
// TODO: 
// YOUR CODE HERE

// output: [4, 3, 6, 9, 9]


